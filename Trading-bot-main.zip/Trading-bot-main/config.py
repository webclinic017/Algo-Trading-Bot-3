SECRET_KEY = "soVOZctpUXlzPRC77NmdYCo3ac3gM0xtXFPfwpzy"
API_KEY = "AK2EG11TF1UW3G3GJ9KL"

ALPACA_CONFIG = {
    "API_KEY" : API_KEY,
    "API_SECRET" : SECRET_KEY,
    "ENDPOINT" : "https://paper-api.alpaca.markets"
}
